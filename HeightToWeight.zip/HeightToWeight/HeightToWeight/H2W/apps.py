from django.apps import AppConfig


class H2WConfig(AppConfig):
    name = 'H2W'
